import { GoogleGenAI, Type } from "@google/genai";

const getApiKey = () => {
  // In Vite, process.env is usually injected via define in vite.config.ts
  // import.meta.env is the standard Vite way for VITE_ prefixed variables
  return (
    (typeof process !== 'undefined' && process.env?.GEMINI_API_KEY) || 
    import.meta.env.VITE_GEMINI_API_KEY || 
    ""
  );
};

const ai = new GoogleGenAI({ apiKey: getApiKey() });

export interface ClimateResponse {
  headline: string;
  weather_summary: string;
  numerical_weather: {
    temp: number;
    feels_like: number;
    humidity: number;
    wind_speed: number;
    condition: string;
    uv_index: number;
  };
  forecast: {
    date: string;
    temp_max: number;
    temp_min: number;
    condition: string;
  }[];
  climate_risks: string[];
  awareness_message: string;
  behavioral_tips: string[];
  risk_level: "Low" | "Medium" | "High" | "Critical";
  language_used: string;
  readability_score: number;
  relevance_score: number;
  cultural_sensitivity_score: number;
  createdAt?: string;
}

export async function generateClimateContent(
  lat: number,
  lon: number,
  city: string,
  country: string,
  audience: string,
  language: string
): Promise<ClimateResponse> {
  const apiKey = getApiKey();
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    throw new Error("Gemini API Key is missing or invalid. Please add your valid API key to the environment variables (GEMINI_API_KEY or VITE_GEMINI_API_KEY).");
  }

  try {
    const model = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `
        You are a Gen Z climate communication expert who is also a weather data pro.
        
        CRITICAL: Use Google Search to find the ACTUAL current weather and a 3-day forecast for ${city}, ${country} (coordinates: ${lat}, ${lon}). 
        Do not hallucinate. The user expects real-time accuracy.
        
        Target Audience: ${audience}
        Response Language: ${language}
        
        Task:
        1. Provide numerical weather data: temp (Celsius), feels_like, humidity (%), wind_speed (km/h), condition (e.g., Sunny, Stormy), and uv_index.
        2. Provide a 3-day forecast (including tomorrow and the next 2 days).
        3. Describe the current weather and seasonal context in a punchy, Gen Z friendly way (use emojis, slang like "no cap", "slay", "vibes", but keep it informative).
        4. Identify the top 3 climate risks relevant to this specific location.
        5. Write a localized awareness message appropriate for ${audience}.
        6. Suggest 3 specific, actionable behavioral changes this audience can make.
        7. Evaluate your own output: provide a readability score (0-100), relevance score (1-10), and cultural sensitivity score (1-10).
        
        Respond ONLY in valid JSON format.
      `,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            headline: { type: Type.STRING },
            weather_summary: { type: Type.STRING },
            numerical_weather: {
              type: Type.OBJECT,
              properties: {
                temp: { type: Type.NUMBER },
                feels_like: { type: Type.NUMBER },
                humidity: { type: Type.NUMBER },
                wind_speed: { type: Type.NUMBER },
                condition: { type: Type.STRING },
                uv_index: { type: Type.NUMBER }
              },
              required: ["temp", "feels_like", "humidity", "wind_speed", "condition", "uv_index"]
            },
            forecast: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  date: { type: Type.STRING },
                  temp_max: { type: Type.NUMBER },
                  temp_min: { type: Type.NUMBER },
                  condition: { type: Type.STRING }
                },
                required: ["date", "temp_max", "temp_min", "condition"]
              }
            },
            climate_risks: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            awareness_message: { type: Type.STRING },
            behavioral_tips: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            risk_level: { 
              type: Type.STRING,
              enum: ["Low", "Medium", "High", "Critical"]
            },
            language_used: { type: Type.STRING },
            readability_score: { type: Type.NUMBER },
            relevance_score: { type: Type.NUMBER },
            cultural_sensitivity_score: { type: Type.NUMBER }
          },
          required: [
            "headline", "weather_summary", "numerical_weather", "forecast", "climate_risks", 
            "awareness_message", "behavioral_tips", "risk_level",
            "readability_score", "relevance_score", "cultural_sensitivity_score"
          ]
        }
      }
    });

    if (!model.text) {
      throw new Error("No text returned from Gemini");
    }

    return JSON.parse(model.text);
  } catch (error) {
    console.error("Gemini Generation Error:", error);
    // Fallback if search fails or other error
    throw error;
  }
}
